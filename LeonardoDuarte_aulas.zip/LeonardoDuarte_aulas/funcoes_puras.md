# Funções puras
*20 de Agosto 2020*  
__BCC - PUCPR__  
__Leonardo Chaves Duarte__  
Funções puras são essenciais na programação funcional pois seguem a filosofia de independencia de estado.  
Funções puras são aquelas que não ateral valores de estados e não dependem de variaveis globais.  
Funções puras recebem todos os dados que necessitam por parametros (argumentos) e retornam um resultado apos a aplicação de um processo a esses dados.
Funções puras são extremamente importantes pois dão a todo software alta modularidade.  
Funções lambda com todas as variaveis ligadas (combinador) são exemplos de função pura.  

__Exemplo:__
soma = a1 -> a2 -> a1+a2